//
//  NShape.h
//  DSDDemo
//
//  Created by Leong on 2/8/2017.
//  Copyright © 2017 Leong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NShape : UIView

@end
