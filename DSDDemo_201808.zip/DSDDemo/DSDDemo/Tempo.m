//
//  Tempo.m
//  DSDDemo
//
//  Created by Leong on 19/8/14.
//  Copyright (c) 2014 Leong. All rights reserved.
//

#import "Tempo.h"

@implementation Tempo

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


@end
