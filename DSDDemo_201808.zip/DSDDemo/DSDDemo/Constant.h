//
//  Constant.h
//  DSDDemo
//
//  Created by Leong on 18/1/13.
//  Copyright (c) 2013 Leong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Constant : NSObject{
    
}

@property int unit_size;
@property int note_gap;
@property int v_spacing_size;
@property int display_size;
@property int v_offset_size;

@end
