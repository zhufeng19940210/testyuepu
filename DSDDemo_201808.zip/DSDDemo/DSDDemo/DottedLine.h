//
//  DottedLine.h
//  DSDDemo
//
//  Created by Leong on 7/5/14.
//  Copyright (c) 2014 Leong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DottedLine : UIView

@end
