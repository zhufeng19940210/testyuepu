//
//  Tempo.h
//  DSDDemo
//
//  Created by Leong on 19/8/14.
//  Copyright (c) 2014 Leong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tempo : UILabel

@property(nonatomic) BOOL shouldBeHide;
@property(nonatomic) int group;
@property(nonatomic) int index;

@end
