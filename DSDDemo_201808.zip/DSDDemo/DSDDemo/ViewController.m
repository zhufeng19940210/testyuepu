//
//  ViewController.m
//  DSDDemo
//
//  Created by Leong on 18/1/13.
//  Copyright (c) 2013 Leong. All rights reserved.
//

#import "ViewController.h"

#include <sys/types.h>

#include <sys/sysctl.h>

#import <QuartzCore/QuartzCore.h>

#import "CSVParser.h"

#import "UIView+Roundify.h"

#import "DottedLine.h"

#import "Tempo.h"

#import "TriangleView.h"

#import "NShape.h"

#define RATIO 2

#define SCALE_FACTOR 0.58

#define SPACE 0

#define SHEET_WIDTH 36*16

#define SHEET_HEIGHT 736

#define FONT_SIZE 4

#define UP_TAG 2000

#define DOWN_TAG 5000

#define TEMPO_TAG 8000

#define BWMODE 2

#define COLORMODE 1

#define EDGE self.view.frame.size.width*0.7


@interface ViewController (){
    int startPage;
    
    CGFloat ratio;
}

@end

@implementation ViewController

- (IBAction)repeatControlChanged:(UISegmentedControl *)sender {
    
    if(sender.selectedSegmentIndex == 1){
        
        int _start = [self.start_TF.text intValue];
        
        int _end = [self.end_TF.text intValue];
        
        if( _end > maxPage){
            
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Invalid input value" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alert show];
            
            [sender setSelectedSegmentIndex:0];
            
            return;
            
        }
        
        if(_start == _end){
            
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Starting bar cannot be same as ending bar" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alert show];
            
            [sender setSelectedSegmentIndex:0];
            
            return;
            
        }
        
        if(_start > _end){
            
            UIAlertView * alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Invalid input value" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            [alert show];
            
            [sender setSelectedSegmentIndex:0];
            
            return;
            
        }
        
        if(_start == (int)nil)
            _start = 0;
        
        [self skipToPage:_start];
        startPage = _start;
        maxPage = (_start == 0)?_end+1:_end;
        
        
    }
    else{
        [self skipToPage:[displayArray[0][@"Bar No(40)"] intValue]];
        startPage = 1;
        maxPage = ([displayArray[0][@"Bar No(40)"] intValue] == 0)?displayArray.count-1:displayArray.count;
        
        self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/2, 182, [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/2, 12);
    }
    
    shaderIndex = 1;

    circleIndex = 0;
    [self showCircularView];
    
    
    
}

- (void)setMode:(int)_mode andFile:(NSString*)_name andHalfLine:(BOOL)enabled andTempo:(int)_t{
    mode = _mode;
    
    fileName = _name;
    
    halfLine = enabled;
    
    minimunTempo = _t;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    ratio = ratio * self.scrollView.bounds.size.height/768;
    
    colorArray = [[NSMutableArray alloc] initWithObjects:[UIColor blackColor],
                  [UIColor colorWithRed:255.0/255.0 green:217/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:255.0/255.0 green:13/255.0 blue:13/255.0 alpha:1.0],
                  [UIColor colorWithRed:255/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:45/255.0 green:45/255.0 blue:255/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:95/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:143/255.0 green:57/255.0 blue:215/255.0 alpha:1.0],
                  
                  [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:1.0],
                  [UIColor colorWithRed:150/255.0 green:150/255.0 blue:150/255.0 alpha:1.0],
                  [UIColor colorWithRed:100/255.0 green:100/255.0 blue:100/255.0 alpha:1.0],
                  
                  [UIColor colorWithRed:50/255.0 green:50/255.0 blue:50/255.0 alpha:1.0],
                  [UIColor colorWithRed:154/255.0 green:132/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:255/255.0 green:51/255.0 blue:51/255.0 alpha:1.0],
                  [UIColor colorWithRed:165/255.0 green:76/255.0 blue:5/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:89/255.0 blue:162/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:176/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:169/255.0 green:102/255.0 blue:224/255.0 alpha:1.0],
                  
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  [UIColor colorWithRed:0/255.0 green:0/255.0 blue:0/255.0 alpha:1.0],
                  nil];
    

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *file = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/data/data/%@.csv", fileName]];
    
    NSArray * arrayOfDictionaries = [CSVParser parseCSVIntoArrayOfDictionariesFromFile:file
                                                          withSeparatedCharacterString:@","
                                                                  quoteCharacterString:@"\""];
    //Channel 42
    displayArray = [[NSMutableArray alloc] init];
    
    //Channel 41
    self.shadowArray = [[NSMutableArray alloc] init];
    
    tempoArray = [[NSMutableArray alloc] init];
    
    upBtnControls = [[NSMutableArray alloc] init];
    
    downBtnControls = [[NSMutableArray alloc] init];
    
    tempLabelControls = [[NSMutableArray alloc] init];
    
    groupControls = [[NSMutableArray alloc] init];
    
    circlesArray = [[NSMutableArray alloc] init];
    
    UIView * circle = [[UIView alloc] initWithFrame:CGRectMake(100,100,12,12)];
    circle.alpha = 1;
    circle.layer.cornerRadius = 6;
    circle.backgroundColor = [UIColor redColor];
    circle.hidden = YES;
    [self.view addSubview:circle];
    
    [circlesArray addObject:circle];
    circle = [[UIView alloc] initWithFrame:CGRectMake(100,100,12,12)];
    circle.alpha = 1;
    circle.layer.cornerRadius = 6;
    circle.backgroundColor = [UIColor blueColor];
    circle.hidden = YES;
    [self.view addSubview:circle];
    
    [circlesArray addObject:circle];
    circle = [[UIView alloc] initWithFrame:CGRectMake(100,100,12,12)];
    circle.alpha = 1;
    circle.layer.cornerRadius = 6;
    circle.backgroundColor = [UIColor greenColor];
    circle.hidden = YES;
    [self.view addSubview:circle];
    
    [circlesArray addObject:circle];
    circle = [[UIView alloc] initWithFrame:CGRectMake(100,100,12,12)];
    circle.alpha = 1;
    circle.layer.cornerRadius = 6;
    circle.backgroundColor = [UIColor blueColor];
    circle.hidden = YES;
    [self.view addSubview:circle];
    [circlesArray addObject:circle];
    
    NSUserDefaults *storeData=[NSUserDefaults standardUserDefaults];
    
    if([storeData valueForKey:fileName] != nil){
        self.shadowArray = [storeData valueForKey:fileName];
    }
    
    for (NSDictionary * dict in arrayOfDictionaries) {
        
        [self drawData:dict];
        
        if([[NSUserDefaults standardUserDefaults] valueForKey:fileName] == nil){
            if([[dict objectForKey:@"channel"] isEqualToString:@"41"]){
                [self.shadowArray addObject:dict];
            }
        }
        
        
        if([[dict objectForKey:@"channel"] isEqualToString:@"42"]){
            [displayArray addObject:dict];
            totalLength += [[dict objectForKey:@"length(109)"] intValue];
        }
    }
    
    self.scrollView.contentSize = CGSizeMake(totalLength, SHEET_HEIGHT);
    
    /*Sorting Channel 42 & 41 Array if the data is not start by Zero*/
    NSArray * sortedArray;
    sortedArray = [displayArray sortedArrayUsingComparator:^NSComparisonResult(NSDictionary * a, NSDictionary * b) {
        int first = [a[@"Bar No(40)"] intValue];
        int second = [b[@"Bar No(40)"] intValue];
        
        if (first > second) {
            return (NSComparisonResult)NSOrderedDescending;
        } else
            return (NSComparisonResult)NSOrderedAscending;
    }];
    
    displayArray = [[NSMutableArray alloc] initWithArray:sortedArray];
    
    sortedArray = [self.shadowArray sortedArrayUsingComparator:^NSComparisonResult(NSDictionary * a, NSDictionary * b) {
        int first = [a[@"Bar No(40)"] intValue];
        int second = [b[@"Bar No(40)"] intValue];
        
        if (first > second) {
            return (NSComparisonResult)NSOrderedDescending;
        } else
            return (NSComparisonResult)NSOrderedAscending;
    }];
    
    self.shadowArray = [[NSMutableArray alloc] initWithArray:sortedArray];
    /*End of Sorting*/
    
    index = 0;
    
    timerFactor = 1;
    
    timer = [[NSTimer alloc]init];
    
    startPage = [displayArray[0][@"Bar No(40)"] intValue];
    
    page = 1;
    
    totalLength = 0;
    
    shaderIndex = 1;
    
    [self initGlobalFactor];
    
    /*Assume the number of channel 42 is equal to the total number of pages*/
    maxPage = ([displayArray[0][@"Bar No(40)"] intValue] == 0)?displayArray.count:displayArray.count+1;

    /*Arragne Shaders*/

    self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 182, [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 12);
    
    circleIndex = 0;

    [self rearrangeTempoControls];
    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

    self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 182/(ratio/2) + 12/(ratio/2), [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 12/(ratio/2));
    
    [self showCircularView];
}

-(void)skipToPage:(int)_page{
    
    int _distance = 0;
    
    int _index = 0;
    
    if(_page > 0){
        for (NSDictionary * _d in displayArray) {
            
            
            
            _distance += [_d[@"length(109)"] intValue];
            _index += [_d[@"Beats per Bar(40)"] intValue];
            
            if([_d[@"Bar No(40)"] intValue] + 1 == _page){
                break;
            }
            
        }
        
        page = _page;
    }
    else{
        page = 1;
        //!!!Page cannot be Zero!!!
    }
    

    [self.scrollView setContentOffset:CGPointMake(_distance/ratio,0) animated:NO];
    movedLength = 0;

    index = _index;

    self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 182/(ratio/2) + 12/(ratio/2), [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio,12/(ratio/2));
}

-(void)showCircularView{
    
    /*Determine to show or not by tempo value*/
    if([self.shadowArray[index][@"tempo (40)"] intValue] < minimunTempo){
        
        CGFloat barWidth = [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] floatValue]/ratio;
        CGFloat spaceForEach = barWidth/4;

        /*Arrange position of circular views*/
        int _i = 0;
        for (UIView * c in circlesArray) {
            
            //[c setHidden:NO];
            c.frame = CGRectMake(self.finalshader.frame.origin.x + spaceForEach*_i + (spaceForEach - 12)/ratio, 182/(ratio/2) + 12/(ratio/2), 12, 12);
            
            _i++;
        }
        
        [(UIView*)circlesArray[0] setHidden:NO];
        
        [self.finalshader setHidden:YES];
        
    }
    else{
        for (UIView * c in circlesArray) {
            
            [c setHidden:YES];
            
        }
        
        [self.finalshader setHidden:NO];
    }
    
}

-(void)circleLife{
    
    for (UIView* view in circlesArray) {
        
        [view setHidden:YES];
        
    }
    
    if([self.shadowArray[index][@"tempo (40)"] intValue] >= minimunTempo)
        return;
    
    circleIndex = (circleIndex < 3)?circleIndex+1:0;

    
    if(circleIndex != 0){
        UIView * nextView = circlesArray[circleIndex];
        [nextView setHidden:NO];
    }
    
    [self startCircleTimer:[self calculateDuration]/4];
    
}

-(void) initGlobalFactor{
    global_factor = 0;
}

-(void) drawData:(NSDictionary *)dict{

    //Ignore Channel 0 with no reason
    if([[dict objectForKey:@"channel"] intValue] == 0 ){
        return;
    }
    
    //Ignore Channel 36 in Color Mode
    if(mode == COLORMODE && [dict[@"channel"] intValue] == 36){
        return;
    }
    
    //Ignore Channel 39 in Color Mode
    if(mode == COLORMODE && [dict[@"channel"] intValue] == 39){
        return;
    }
    
    //Ignore Channel 52 in Color Mode
    if(mode == COLORMODE && [dict[@"channel"] intValue] == 52){
        return;
    }
    
    //Ignore Channel 57 in Color Mode
    if(mode == BWMODE && [dict[@"channel"] intValue] == 57){
        return;
    }
    
    if([dict[@"channel"] intValue] == 37){
        if([dict[@"Content"] isEqualToString:@"n"]){
            NShape * n = [[NShape alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio, [[dict objectForKey:@"height(110)"] floatValue]/ratio)];
            
            [self.scrollView addSubview:n];
        }
    }
    
    //Sign
    if([[dict objectForKey:@"channel"] intValue] == 29 ){
        
        NSString * imgName;
        
        if([[dict objectForKey:@"Content"] isEqualToString:@"G-clef"]){
            imgName = @"g_clef.png";
        }
        else{
            imgName = @"f_clef.png";
        }
        
        UIImageView * img = [[UIImageView alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, 35, 90)];
        img.image = [UIImage imageNamed:imgName];
        
        
        [self.keyView addSubview:img];
    }
    
    //Adjustment Item
    if([[dict objectForKey:@"channel"] intValue] == 41 ){
        
        UIButton * showBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        showBtn.frame = CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"rise_fall"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio, [[dict objectForKey:@"height(110)"] floatValue]*3);
        showBtn.tag = ([[dict objectForKey:@"Bar No(40)"] intValue]) * [[dict objectForKey:@"flip_view"] intValue] + [[dict objectForKey:@"Beats per Bar(40)"] intValue];
        [showBtn addTarget:self action:@selector(showControl:) forControlEvents:UIControlEventTouchDown];
        
        UILongPressGestureRecognizer *gr = [[UILongPressGestureRecognizer alloc] init];
        [gr addTarget:self action:@selector(userLongPressed:)];
        [showBtn addGestureRecognizer:gr];
        
        Tempo * label = nil;
        label = [[Tempo alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, 24, 12)];
        label.textColor = [UIColor blackColor];
        label.font = [UIFont fontWithName:@"Arial" size:FONT_SIZE*2.7/(ratio/2)];
        label.tag = TEMPO_TAG + ([[dict objectForKey:@"Bar No(40)"] intValue]) * [[dict objectForKey:@"flip_view"] intValue] + [[dict objectForKey:@"Beats per Bar(40)"] intValue];
        
        
        if([[NSUserDefaults standardUserDefaults] valueForKey:fileName] != nil){
            NSDictionary * tmp_dict = [self.shadowArray objectAtIndex:label.tag - TEMPO_TAG - 1];
            label.text = [tmp_dict objectForKey:@"tempo (40)"];
            
        }
        else{
            label.text = [dict objectForKey:@"tempo (40)"];
            
        }
        
        label.group = [[dict objectForKey:@"Bar No(40)"] intValue];
        label.index =[[dict objectForKey:@"Beats per Bar(40)"] intValue];
        
        NSLog(@"Before Bar Number is %d", label.group);
        
        label.hidden = YES;
        
        UIButton * upBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        upBtn.frame = CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"rise_fall"] floatValue]/ratio, 25, 25);
        upBtn.tag = UP_TAG + ([[dict objectForKey:@"Bar No(40)"] intValue]) * [[dict objectForKey:@"flip_view"] intValue] + [[dict objectForKey:@"Beats per Bar(40)"] intValue];
        upBtn.backgroundColor = [UIColor clearColor];
        [upBtn addTarget:self action:@selector(addTempo:) forControlEvents:UIControlEventTouchUpInside];
        [upBtn setTitle:@"+" forState:UIControlStateNormal];
        upBtn.hidden = YES;
        
        UIButton * downBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        downBtn.frame = CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"sharp_flat"] floatValue]/ratio, 25, 25);
        downBtn.tag = DOWN_TAG + ([[dict objectForKey:@"Bar No(40)"] intValue]) * [[dict objectForKey:@"flip_view"] intValue] + [[dict objectForKey:@"Beats per Bar(40)"] intValue];
        [downBtn addTarget:self action:@selector(subtractTempo:) forControlEvents:UIControlEventTouchDown];
        [downBtn setTitle:@"-" forState:UIControlStateNormal];
        downBtn.hidden = YES;
        
        
        [upBtnControls addObject:upBtn];
        [downBtnControls addObject:downBtn];
        
        
        if([groupControls count] == 0 || ((Tempo*)[groupControls lastObject]).group == label.group){
            [groupControls addObject:label];
        }
        else{
            
            [tempLabelControls addObject:groupControls];
            groupControls = [[NSMutableArray alloc] init];
            [groupControls addObject:label];
            NSLog(@"Tempo Count : %d", tempLabelControls.count);
        }
        
        if([dict[@"flip_view"] intValue] == groupControls.count){
            [tempLabelControls addObject:groupControls];
        }
        
        //[tempLabelControls addObject:label];
        
        showBtn.layer.zPosition = 9999;
        label.layer.zPosition = 9999;
        upBtn.layer.zPosition = 9999;
        downBtn.layer.zPosition = 9999;
        
        
        [self.scrollView addSubview:showBtn];
        [self.scrollView addSubview:label];
        [self.scrollView addSubview:upBtn];
        [self.scrollView addSubview:downBtn];
        
        [tempoArray addObject:label];
    }
    //KeyView Item
    else if([[dict objectForKey:@"channel"] intValue] == 30 ){
        
        UILabel * label = nil;
        label = [[UILabel alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, 75, 12)];
        label.textColor = [UIColor blackColor];
        label.font = [UIFont fontWithName:@"Arial" size:FONT_SIZE*2.7/(ratio/2)];
        label.text = [dict objectForKey:@"Content"];
        label.backgroundColor = [UIColor clearColor];
        [self.keyView addSubview:label];
        
        [self.view sendSubviewToBack:self.scrollView];
    }
    //#,b
    else if([[dict objectForKey:@"channel"] intValue] == 36 ){
        
        UILabel * label = nil;
        label = [[UILabel alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio,[[dict objectForKey:@"height(110)"] floatValue]/ratio)];
        
        NSString *platform = [self platform];
        
        if ([platform isEqualToString:@"iPad6,8"] || [platform isEqualToString:@"iPad6,7"]) {
            
            label.frame = CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, (int)([[dict objectForKey:@"length(109)"] floatValue]/2.7),(int)([[dict objectForKey:@"height(110)"] floatValue]/2.7));
            
        }
        
        label.textColor = [UIColor colorWithRed:[[dict objectForKey:@"fingering/chord"] floatValue]/255.0 green:[[dict objectForKey:@"lyrics"] floatValue]/255.0 blue:[[dict objectForKey:@"ipad_color(105)"] floatValue]/255.0 alpha:1];
        label.font = [UIFont fontWithName:@"Arial-Italic" size:FONT_SIZE*[[dict objectForKey:@"flip_view"] floatValue]/(ratio/2)];
        label.font = [label.font fontWithSize:FONT_SIZE*[[dict objectForKey:@"flip_view"] floatValue]/(ratio/2)];
        label.text = [dict objectForKey:@"Content"];
            
        label.backgroundColor = [UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1];
        
        label.layer.zPosition = [[dict objectForKey:@"Z-level"] intValue];
        
        
        [self.scrollView addSubview:label];
    }
    //Wording
    else if(([[dict objectForKey:@"channel"] intValue] > 30 && [[dict objectForKey:@"channel"] intValue] < 38 && [[dict objectForKey:@"channel"] intValue] != 36) || [[dict objectForKey:@"channel"] intValue] == 50){
        
        if([[dict objectForKey:@"Content"] isEqualToString:@"n"])return;
        
        UILabel * label = nil;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/(2.5), 12/(ratio/2))];
        
        NSString *platform = [self platform];
        
        if ([platform isEqualToString:@"iPad6,8"] || [platform isEqualToString:@"iPad6,7"]) {
            
            label.frame = CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, (int)([[dict objectForKey:@"length(109)"] floatValue]/2.5), (int)(12/(ratio/2)));
            
        }
        
        label.textColor = [UIColor blackColor];
        label.font = [UIFont fontWithName:@"Arial" size:FONT_SIZE*[[dict objectForKey:@"flip_view"] floatValue]/(ratio/2)];
        label.text = [dict objectForKey:@"Content"];
        
        label.backgroundColor = [UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1];

        
        label.layer.zPosition = [[dict objectForKey:@"Z-level"] intValue];
        
        [self.scrollView addSubview:label];
        
        
    }
    //DottedLine
    else if([[dict objectForKey:@"channel"] intValue] == 14){
        
        if(!halfLine)
            return;
        
        DottedLine * view = [[DottedLine alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio, [[dict objectForKey:@"height(110)"] floatValue]/ratio)];
        view.backgroundColor = [UIColor clearColor];
        view.layer.zPosition = [[dict objectForKey:@"Z-level"] intValue];
        [self.scrollView addSubview:view];
    }
    //Triangle
    else if([[dict objectForKey:@"channel"] intValue] == 58 ){
        UIView * view = [[UIView alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio, [[dict objectForKey:@"height(110)"] floatValue]/ratio)];
        view.backgroundColor = [UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1];
        
        if(mode == BWMODE ){
             view.backgroundColor = [UIColor colorWithRed:150.0/255.0 green:0.0/255.0 blue:0/255.0 alpha:1];
        }
        
        TriangleView * triangle;
        
        if([[dict objectForKey:@"Content"] isEqualToString:@"U"]){
            
            triangle = [[TriangleView alloc] initWithFrame:CGRectMake(2, -12, 320, 320)];
            triangle.backgroundColor = [UIColor clearColor];
            
            if(mode == BWMODE ){
                [triangle setColor:[UIColor colorWithRed:150.0/255.0 green:0.0/255.0 blue:0/255.0 alpha:1]];
            }
            else{
                [triangle setColor:[UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1]];
            }
            

            [triangle setType:@"U"];
            [view addSubview:triangle];
        }
        
        if([[dict objectForKey:@"Content"] isEqualToString:@"D"]){
            
            triangle = [[TriangleView alloc] initWithFrame:CGRectMake(2, -12, 320, 320)];
            triangle.backgroundColor = [UIColor clearColor];
            
            if(mode == BWMODE ){
                [triangle setColor:[UIColor colorWithRed:150.0/255.0 green:0.0/255.0 blue:0/255.0 alpha:1]];
            }
            else{
                [triangle setColor:[UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1]];
            }
            
            [triangle setType:@"D"];
            [view addSubview:triangle];
        }
        
        NSString *platform = [self platform];
        
        [triangle setSize:NO];
        
        if ([platform isEqualToString:@"iPad6,8"] || [platform isEqualToString:@"iPad6,7"]) {
            
            triangle.frame = CGRectMake(2, -9, 320, 320);
            
            [triangle setSize:YES];
            
        }
        
        view.layer.zPosition = [[dict objectForKey:@"Z-level"] intValue];
        
        
        
        [self.scrollView addSubview:view];
    }
    else{
        
        UIView * view = [[UIView alloc] initWithFrame:CGRectMake([[dict objectForKey:@"ipad_col(107)"] floatValue]/ratio, [[dict objectForKey:@"ipad_rows"] floatValue]/ratio, [[dict objectForKey:@"length(109)"] floatValue]/ratio, [[dict objectForKey:@"height(110)"] floatValue]/ratio)];
        view.backgroundColor = [UIColor colorWithRed:[[dict objectForKey:@"Bar No(40)"] floatValue]/255.0 green:[[dict objectForKey:@"Beats per Bar(40)"] floatValue]/255.0 blue:[[dict objectForKey:@"tempo (40)"] floatValue]/255.0 alpha:1];
        

        
        if([[dict objectForKey:@"channel"] intValue] == 20){
            view.backgroundColor = [UIColor redColor];
        }
        
        if([[dict objectForKey:@"flip_view"] intValue] > 0){
            CGFloat borderWidth = [[dict objectForKey:@"flip_view"] floatValue];
            view.layer.borderColor = [UIColor blackColor].CGColor;
            view.layer.borderWidth = borderWidth;
        }
        
        
        
        UILabel * label = nil;
        

        
        //Apply Gray color in channel 1 under BW Mode
        if(mode == BWMODE && [dict[@"channel"] intValue] == 1){
            view.backgroundColor = [UIColor colorWithRed:150.0/255.0 green:0.0/255.0 blue:0/255.0 alpha:1];
        }
        
        UIImageView * img = nil;
        
        
        if([[dict objectForKey:@"channel"] isEqualToString:@"105"] || [[dict objectForKey:@"channel"] isEqualToString:@"110"])
            [view addRoundedCorners:UIRectCornerTopRight withRadii:CGSizeMake(15, 15)];
        
        if([[dict objectForKey:@"channel"] isEqualToString:@"106"]){
            [view addRoundedCorners:(UIRectCornerTopRight|UIRectCornerBottomRight) withRadii:CGSizeMake(15, 15)];
        }

        
        view.layer.zPosition = [[dict objectForKey:@"Z-level"] intValue];
        
        if(([[dict objectForKey:@"channel"] intValue] == 53 || [[dict objectForKey:@"channel"] intValue] == 54) && mode == BWMODE){
            view.backgroundColor = [UIColor colorWithRed:150.0/255.0 green:0.0/255.0 blue:0/255.0 alpha:1];
        }
        
        [self.scrollView addSubview:view];
        
        if([[dict objectForKey:@"channel"] intValue] == 6 || [[dict objectForKey:@"channel"] intValue] == 7){
            [self.scrollView sendSubviewToBack:view];
            return;
        }
        
        
    }
    
}

- (void) rearrangeTempoControls{
    
    
    for (NSMutableArray * group in tempLabelControls) {
        
        BOOL all_same_value = YES;
        
        int value = [((Tempo*) [group firstObject]).text intValue];
        
        for (Tempo * label in group) {
            
            if(value != [label.text intValue]){
                all_same_value = NO;
            }
            
            NSLog(@"Bar Number is %d", label.group);
            
            [label setHidden:YES];
            
        }
        
        
        if(all_same_value){
            
            [((Tempo*) [group firstObject]) setHidden:NO];
        }
        else{
            for (Tempo * label in group) {
                [label setHidden:NO];
                
            }
        }
        
    }
    
}

- (void)userLongPressed:(UILongPressGestureRecognizer*)sender {
    int tag = (int)sender.view.tag;
    
    NSDictionary * dict = [self.shadowArray objectAtIndex:tag-1];
    
    int _index = tag % [[dict objectForKey:@"flip_view"] intValue];
    
    int target = 0;
    
    if(_index == 0){
        
        target = tag - ([[dict objectForKey:@"flip_view"] intValue] - 1);
        
    }
    else{
        
        target = tag - (_index - 1);
        
    }
    
    for (int i = target; i < target + [[dict objectForKey:@"flip_view"] intValue]; i++) {
        UILabel * tempo = (UILabel*)[self.view viewWithTag:i + TEMPO_TAG];
        tempo.hidden = NO;
        
        UIButton * upBtn = (UIButton*)[self.view viewWithTag:i + UP_TAG];
        upBtn.hidden = NO;
        
        UIButton * downBtn = (UIButton*)[self.view viewWithTag:i + DOWN_TAG];
        downBtn.hidden = NO;
    }
    
}

-(void) showControl:(UIButton*)sender{
    
    int tag = (int)sender.tag;
    
    Tempo * tempo = (Tempo*)[self.view viewWithTag:tag + TEMPO_TAG];
    tempo.hidden = NO;
    
    UIButton * upBtn = (UIButton*)[self.view viewWithTag:tag + UP_TAG];
    upBtn.hidden = NO;
    
    UIButton * downBtn = (UIButton*)[self.view viewWithTag:tag + DOWN_TAG];
    downBtn.hidden = NO;
    
}

-(void) addTempo:(UIButton*)sender{
    int tag = (int)sender.tag - UP_TAG;
    
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        NSMutableDictionary * dict = [[self.shadowArray objectAtIndex:tag-1] mutableCopy];
        
        Tempo * label = (Tempo *)[self.scrollView viewWithTag:tag + TEMPO_TAG];
        
        [label setText:[NSString stringWithFormat:@"%d", ([label.text intValue]+1)]];
        

        
        [dict setObject:[NSString stringWithFormat:@"%d", [label.text intValue]] forKey:@"tempo (40)"];
        
        NSMutableArray * sArray = [self.shadowArray mutableCopy];
        
        [sArray replaceObjectAtIndex:tag-1 withObject:dict];
        
        self.shadowArray = [sArray mutableCopy];
        
        NSLog(@"%d", tag-1);
    });
    
    
    
}

-(void) subtractTempo:(UIButton*)sender{
    int tag = (int)sender.tag - DOWN_TAG;
    
    dispatch_async(dispatch_get_main_queue(), ^(void) {
        NSMutableDictionary * dict = [[self.shadowArray objectAtIndex:tag-1] mutableCopy];
        
        Tempo * label = (Tempo *)[self.scrollView viewWithTag:tag + TEMPO_TAG];
        
        [label setText:[NSString stringWithFormat:@"%d", ([label.text intValue]-1)]];
        
        
        
        [dict setObject:[NSString stringWithFormat:@"%d", [label.text intValue]] forKey:@"tempo (40)"];
        
        NSMutableArray * sArray = [self.shadowArray mutableCopy];
        
        [sArray replaceObjectAtIndex:tag-1 withObject:dict];
        
        self.shadowArray = [sArray mutableCopy];
        
        NSLog(@"%d", tag-1);
    });

    
}

-(void) tempoValue{
    
    int _i = 0;
    for (Tempo * label in tempoArray) {
        
        if(([label.text intValue]+global_factor) > 0){
            
            [label setText:[NSString stringWithFormat:@"%d", [label.text intValue]+global_factor]];
            
            NSMutableDictionary * dict = [[self.shadowArray objectAtIndex:_i] mutableCopy];
            
            [dict setObject:[NSString stringWithFormat:@"%d", [label.text intValue]] forKey:@"tempo (40)"];
            
            NSMutableArray * sArray = [self.shadowArray mutableCopy];
            
            [sArray replaceObjectAtIndex:_i withObject:dict];
            
            self.shadowArray = [sArray mutableCopy];
        }
        
        _i++;
        
    }
}

-(void)updateDisplayArray{
    [[NSUserDefaults standardUserDefaults] setObject:displayArray forKey:[NSString stringWithFormat:@"%@displayArray", fileName]];
}

- (IBAction)backtoModeSelection:(id)sender {
    
    [timer invalidate];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(float) calculateDuration{
    
    return 60/[[[self.shadowArray objectAtIndex:index] objectForKey:@"tempo (40)"] floatValue];
}



-(void) moveShader{

    self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 182/(ratio/2) + 12/(ratio/2), [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/ratio, 12/(ratio/2));
    [self showCircularView];
    [self startTimer:[self calculateDuration]];
    
    
    
    
    
}

-(void)resetCircle{
    for (UIView* view in circlesArray) {
        
        [view setHidden:YES];
        
    }
    
    circleIndex = 0;
    
    [circletimer invalidate];
}

-(void)startCircleTimer:(float)time{
    if([circletimer isValid]){
        [circletimer invalidate];
    }
    
    circletimer =  [NSTimer scheduledTimerWithTimeInterval: time/timerFactor target:self selector:@selector(circleLife) userInfo:nil repeats:NO];
}

-(void)startTimer:(float)time{
    if([timer isValid]){
        [timer invalidate];
    }

    timer =  [NSTimer scheduledTimerWithTimeInterval: time/timerFactor target:self selector:@selector(next:) userInfo:nil repeats:NO];
}

- (IBAction)next:(id)sender {
    
    [self startTimer:[self calculateDuration]];
    [self resetCircle];
    [self startCircleTimer:[self calculateDuration]/4];
    [self nextSection];
    
    [self.leftShader setHidden:NO];
    [self.rightShader setHidden:NO];
}

- (IBAction)play:(id)sender {
    
    [self startTimer:[self calculateDuration]];
    [self startCircleTimer:[self calculateDuration]/4];
    
    [self.leftShader setHidden:NO];
    [self.rightShader setHidden:NO];
    
    [self.repeat_SC setEnabled:NO];
}

- (IBAction)pause:(id)sender {
    [timer invalidate];
    [circletimer invalidate];
    
    [self.leftShader setHidden:YES];
    [self.rightShader setHidden:YES];
    
    [self.repeat_SC setEnabled:YES];
}

- (IBAction)previous:(id)sender {
    [self startTimer:[self calculateDuration]];
    [self previousSection];
    
    [self.leftShader setHidden:NO];
    [self.rightShader setHidden:NO];
    
}

- (IBAction)changeOpacity:(UISlider*)sender {
    [self.leftShader setAlpha:sender.value];
    [self.rightShader setAlpha:sender.value];
}



- (IBAction)saveChanges:(UIButton *)sender {
    
    
    for (NSMutableArray * group in tempLabelControls) {
        for (Tempo * label in group) {
            if(label.shouldBeHide)
                label.hidden = YES;
        }
    }
    
    for (UIButton * btn in upBtnControls) {
        btn.hidden = YES;
    }
    
    for (UIButton * btn in downBtnControls) {
        btn.hidden = YES;
    }
    
    NSUserDefaults *storeData=[NSUserDefaults standardUserDefaults];
    [storeData setObject:self.shadowArray forKey:fileName];
    [storeData synchronize];
    
    [self rearrangeTempoControls];
    
}

-(int) getSectionNumber{
    for(int i=1;i<[self.dict count];i++){
        if(page-1 == [[[self.dict objectForKey:[NSString stringWithFormat:@"%d", i]] objectForKey:@"bars"] intValue]){
            return [[[self.dict objectForKey:[NSString stringWithFormat:@"%d", i]] objectForKey:@"time_sig_n"] intValue];
        }
    }
    
    return 0;
}

-(void)nextSection{
    
    if(shaderIndex+1 > [[[displayArray objectAtIndex:page-1] objectForKey:@"Beats per Bar(40)"] intValue]){
        shaderIndex = 1;
        if(page == maxPage){
            
            [self skipToPage:startPage];
            [self moveShader];
            return;

        }
        else{
            movedLength += [[[displayArray objectAtIndex:page-1] objectForKey:@"length(109)"] floatValue] /ratio;
            index++;
        }
        page++;
        [self changePage];
        
    }
    else{
        shaderIndex++;
        index++;
    }
    
    [self moveShader];
}

-(void)previousSection{
    if(sectionNow - 1 > 0){
        sectionNow--;
    }
    else{
        if(page - 1 < 1)
            return;
        page--;
        sectionNow = [self getSectionNumber];
        [self changePage];
    }
    [self moveShader];
}

-(void)renewData{
    
    sectionNow = 1;
}

-(void) changePage{
    
    BOOL needChangePage = NO;
    
    CGFloat nowPosition = self.leftShader.frame.origin.x + self.leftShader.frame.size.width;
    CGFloat lengthToNextTwoBar = 0.0;
    for(int i=2;i<1;i--){
        lengthToNextTwoBar += [displayArray[page-i][@"length(109)"] floatValue]/2;
    }
    
    CGFloat startingPoint = nowPosition + lengthToNextTwoBar;
    
    CGFloat edge = EDGE;
    
    NSString *platform = [self platform];
    
    if ([platform isEqualToString:@"iPad6,8"] || [platform isEqualToString:@"iPad6,7"]) {
        
        edge = self.view.frame.size.width*0.85;
        
    }
    
    if(page+1 <= displayArray.count){
        if(startingPoint < edge && (startingPoint + [displayArray[page][@"length(109)"] floatValue]/ratio) > edge && ((page - ((startPage == 0)?1:0))) != maxPage){
            needChangePage = YES;
        }
        
        if(needChangePage){
            needChangePage = [self checkBarsInView:page-1];
        }
    }

    
    if(!needChangePage)
        return;

    self.finalshader.frame = CGRectMake(self.rightShader.frame.origin.x - [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/2, 182, [[[self.shadowArray objectAtIndex:index] objectForKey:@"length(109)"] intValue]/2, 12);
    
    if(page > startPage){
        [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x + movedLength,0) animated:NO];
    }
    else{
        [self.scrollView setContentOffset:CGPointMake(0,0) animated:NO];
    }
    
    movedLength = 0;
}

-(BOOL) checkBarsInView:(int) _page{
    
    CGFloat length = 0.0;
    for(int i=_page;i<maxPage;i++){
        length+= [displayArray[i][@"length(109)"] floatValue]/2;
    }
    
    if(self.rightShader.frame.origin.x + length <= self.view.bounds.size.width){
        return NO;
    }
    
    return YES;
}

- (IBAction)increase:(id)sender {
    global_factor = 1;
    [self tempoValue];

    
}

- (IBAction)decrease:(id)sender {
    global_factor = -1;
    [self tempoValue];
    

    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (UIImage *)scaleImage:(UIImage *)image toScale:(float)scaleSize
{
    UIGraphicsBeginImageContext(CGSizeMake(image.size.width*scaleSize,image.size.height*scaleSize));
    [image drawInRect:CGRectMake(0, 0, image.size.width * scaleSize, image.size.height *scaleSize)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

- (UIImage *)captureImageFromView:(UIView *)theView {
    
    UIGraphicsBeginImageContextWithOptions(theView.bounds.size, theView.opaque, 0.0);
    [theView.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *captureImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return captureImage;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (void)viewDidUnload {
    [self setScrollView:nil];
    [self setLeftShader:nil];
    [self setRightShader:nil];
    [self setPercentageLabel:nil];
    [self setPanelView:nil];
    [self setTimeLabel2:nil];
    [self setTimeLabel1:nil];
    [self setTimeLabel3:nil];
    [self setTimeLabel4:nil];
    [self setTime1:nil];
    [self setTime2:nil];
    [self setTime3:nil];
    [self setTime4:nil];
    [super viewDidUnload];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

- (NSString *) platform{
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithUTF8String:machine];
    free(machine);
    return platform;
}

@end
