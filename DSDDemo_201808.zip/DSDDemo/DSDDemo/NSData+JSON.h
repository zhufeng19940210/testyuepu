//
//  NSData+JSON.h
//  StaffSocialNetwork
//
//  Created by Gary on 29/9/13.
//  Copyright (c) 2013 Nuthon IT Solutions Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (JSON)


- (id)JSONObject;
- (NSString *)string;


@end
