//
//  ViewController.h
//  DSDDemo
//
//  Created by Leong on 18/1/13.
//  Copyright (c) 2013 Leong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    
    int bar;
    NSMutableArray * dictArray;
    
    int sectionNow;
    
    NSTimer * timer;
    
    int page;
    
    int maxPage;
    float timerFactor;
    
    NSMutableArray * displayArray;
    
    //02-07-2013
    NSString * fileName;
    
    int openedTag;
    
    int totalLength;
    
    float movedLength;
    
    NSMutableArray * sheetArray;
    
    int shaderIndex;
    
    NSMutableArray * colorArray;
    
    
    
    NSMutableArray * tempoArray;
    
    int index;
    
    NSMutableArray * upBtnControls;
    NSMutableArray * downBtnControls;
    NSMutableArray * tempLabelControls;
    
    NSMutableArray * groupControls;
    
    int mode;
    
    int global_factor;
    
    NSMutableArray * circlesArray;
    int circleIndex;
    NSTimer * circletimer;
    
    BOOL halfLine;
    
    int minimunTempo;
}

@property(strong, nonatomic) NSMutableDictionary * dict;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *leftShader;
@property (strong, nonatomic) IBOutlet UIView *rightShader;
@property (strong, nonatomic) IBOutlet UIView *upShader;
@property (strong, nonatomic) IBOutlet UIView *downShader;
@property (strong, nonatomic) IBOutlet UIView *finalshader;
@property (strong, nonatomic) IBOutlet UILabel *percentageLabel;
@property (strong, nonatomic) IBOutlet UIView *panelView;
@property (strong, nonatomic) IBOutlet UITextField *timeLabel2;
@property (strong, nonatomic) IBOutlet UITextField *timeLabel1;
@property (strong, nonatomic) IBOutlet UITextField *timeLabel3;
@property (strong, nonatomic) IBOutlet UITextField *timeLabel4;

@property(strong, nonatomic)NSMutableArray * shadowArray;;

@property (strong, nonatomic) IBOutlet UILabel *time1;
@property (strong, nonatomic) IBOutlet UILabel *time2;
@property (strong, nonatomic) IBOutlet UILabel *time3;
@property (strong, nonatomic) IBOutlet UILabel *time4;

@property (strong, nonatomic) IBOutlet UIView *keyView;

@property (strong, nonatomic) IBOutlet UISegmentedControl *repeat_SC;
@property (strong, nonatomic) IBOutlet UITextField *start_TF;
@property (strong, nonatomic) IBOutlet UITextField *end_TF;
- (IBAction)repeatControlChanged:(UISegmentedControl *)sender;

- (void)setMode:(int)_mode andFile:(NSString*)_name andHalfLine:(BOOL)enabled andTempo:(int)_t;

- (IBAction)changeOpacity:(UISlider*)sender;


- (IBAction)increase:(id)sender;
- (IBAction)decrease:(id)sender;
- (IBAction)saveChanges:(UIButton *)sender;

-(void) updateDisplayArray;
- (IBAction)backtoModeSelection:(id)sender;

@end
